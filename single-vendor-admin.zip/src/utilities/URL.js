// export const BASE_URL = "https://backend.fomino.ch:3041/";
// export const BASE_URL = "https://test.fomino.ch:8000/";
export const BASE_URL = " http://192.168.18.52:3042/";
export const SOCKET_URL = "wss://backend.fomino.ch:3041";
// export const googleApiKey = "AIzaSyAVYbP2F93xvY4i59UVNfAfYR62dmbKNFA"
export const googleApiKey = "AIzaSyD68_vw1gGE7LVVjJ5ZShy7qWwm9Rq0CBQ";
